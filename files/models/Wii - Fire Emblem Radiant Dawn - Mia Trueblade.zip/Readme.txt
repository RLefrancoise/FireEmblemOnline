Those models were ripped by Vert092, no credit needed. The UV maps of those models are vertically flipped,
so if the texture does not work for you, flip the texture images 180� and mirror it.